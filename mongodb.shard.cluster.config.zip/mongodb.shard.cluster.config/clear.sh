#!/bin/sh


cd /opt/mongodb/data
rm -rf *

cd /opt/mongodb/log
rm -rf *