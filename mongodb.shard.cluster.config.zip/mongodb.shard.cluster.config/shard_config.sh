#!/bin/sh

MONGODB_INSTALL_PATH=/opt/mongodb
MGCONFIG=config
MGDATA=data
MGLOG=log

# Config文件存放路径
MONGODB_CONFIG_PATH=$MONGODB_INSTALL_PATH/$MGCONFIG/shard

CONFIG_SERVER_FILE=$MONGODB_CONFIG_PATH/configsvr.conf
SHARD_1_FILE=$MONGODB_CONFIG_PATH/shard1.conf
SHARD_2_FILE=$MONGODB_CONFIG_PATH/shard2.conf
SHARD_3_FILE=$MONGODB_CONFIG_PATH/shard3.conf
ROUTER_FILE=$MONGODB_CONFIG_PATH/mongosrouter.conf

echo "-------------------------Create Dirs------------------------------" 
cd $MONGODB_INSTALL_PATH

mkdir $MGDATA $MGLOG 
cd $MGDATA
mkdir 27100 30000 27020 27021 27022

echo "-------------------------configsvr------------------------------" 
mongod --config $CONFIG_SERVER_FILE


echo "-------------------------shard1------------------------------" 
mongod --config $SHARD_1_FILE


echo "-------------------------shard2------------------------------"
mongod --config $SHARD_2_FILE


echo "-------------------------shard3------------------------------" 
mongod --config $SHARD_3_FILE

