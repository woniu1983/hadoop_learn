#!/bin/sh


echo "-------------------------Execute MongoDB: Config and Shard Replica Set------------------------------" 
echo "-----------------------------------------------------------------------------------------------------------"

echo "**************************** Login HA11 *************************************" 
ssh -tt ha11.woniu.com << ooxx1

echo "-------------------------Execute shard_config.sh------------------------------" 
/opt/mongodb/config/shard_config.sh

exit
ooxx1
echo "************************** END HA11 *****************************************" 



echo "**************************** Login HA22 *************************************" 
ssh -tt ha22.woniu.com << ooxx2

echo "-------------------------Execute shard_config.sh------------------------------" 
/opt/mongodb/config/shard_config.sh

exit
ooxx2
echo "************************** END HA22 *****************************************" 



echo "**************************** Login HA33 *************************************" 
ssh -tt ha33.woniu.com << ooxx3

echo "-------------------------Execute shard_config.sh------------------------------" 
/opt/mongodb/config/shard_config.sh

exit
ooxx3
echo "************************** END HA33 *****************************************" 


echo "**************************** Config ReplicaSet initial *************************************" 
CONF_INI='mongo --host ha11.woniu.com --port 27100'
$CONF_INI <<xxxconfig
rs.initiate({ _id: "confrp",configsvr: true, members: [{ _id : 0, host : "ha11.woniu.com:27100" }, { _id : 1, host : "ha22.woniu.com:27100" }, { _id : 2, host : "ha33.woniu.com:27100" }]})

exit
xxxconfig


echo "**************************** Shard1 ReplicaSet initial *************************************" 
CONF_INI='mongo --host ha11.woniu.com --port 27020'
$CONF_INI <<shard1
rs.initiate({ _id: "shard1", members: [{ _id : 0, host : "ha11.woniu.com:27020" }, { _id : 1, host : "ha22.woniu.com:27020" }, { _id : 2, host : "ha33.woniu.com:27020" }]})

exit
shard1


echo "**************************** Shard2 ReplicaSet initial *************************************" 
CONF_INI='mongo --host ha22.woniu.com --port 27021'
$CONF_INI <<shard2
rs.initiate({ _id: "shard2",members: [{ _id : 0, host : "ha11.woniu.com:27021" }, { _id : 1, host : "ha22.woniu.com:27021" }, { _id : 2, host : "ha33.woniu.com:27021" }]})

exit
shard2


echo "**************************** Shard3 ReplicaSet initial *************************************" 
CONF_INI='mongo --host ha33.woniu.com --port 27022'
$CONF_INI <<shard3
rs.initiate({ _id: "shard3",members: [{ _id : 0, host : "ha11.woniu.com:27022" }, { _id : 1, host : "ha22.woniu.com:27022" }, { _id : 2, host : "ha33.woniu.com:27022" }]})

exit
shard3



echo "**************************** Login HA11 For Mongos Router *************************************" 
ssh -tt ha11.woniu.com << mongosrouter

echo "-------------------------Execute shard_config.sh------------------------------" 
/opt/mongodb/config/shard_mongos.sh

exit
mongosrouter
echo "************************** END*****************************************"

echo "**************************** Add Shard *************************************" 
MONGOS_INI='mongo ha11.woniu.com:30000'
$MONGOS_INI << shardadd
sh.addShard( "shard1/ha11.woniu.com:27020" )
sh.addShard( "shard2/ha22.woniu.com:27021" )
sh.addShard( "shard3/ha33.woniu.com:27022" )

exit
shardadd
echo "**************************** Add Shard Finished *************************************" 

