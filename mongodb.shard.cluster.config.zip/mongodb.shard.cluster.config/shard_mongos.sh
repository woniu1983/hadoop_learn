#!/bin/sh

MONGODB_INSTALL_PATH=/opt/mongodb
MGCONFIG=config
MGDATA=data
MGLOG=log

# Config文件存放路径
MONGODB_CONFIG_PATH=$MONGODB_INSTALL_PATH/$MGCONFIG/shard

CONFIG_SERVER_FILE=$MONGODB_CONFIG_PATH/configsvr.conf
SHARD_1_FILE=$MONGODB_CONFIG_PATH/shard1.conf
SHARD_2_FILE=$MONGODB_CONFIG_PATH/shard2.conf
SHARD_3_FILE=$MONGODB_CONFIG_PATH/shard3.conf
ROUTER_FILE=$MONGODB_CONFIG_PATH/mongosrouter.conf


echo "-------------------------mongos------------------------------" 
mongos --config $ROUTER_FILE

